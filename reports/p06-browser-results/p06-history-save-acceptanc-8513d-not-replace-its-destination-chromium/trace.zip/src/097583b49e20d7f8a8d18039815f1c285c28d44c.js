import { test, expect } from '@playwright/test'
import { randomUUID } from 'node:crypto'
import { apiGetPresentation, apiUpdatePresentation } from './fixtures/test-fixtures.js'
import { historyJourney, titleInput, quick, holdNextSave, saved, slide } from './helpers/p06-history-acceptance.js'
import { createHistoryPackage } from './helpers/p06-history-package.js'

test('P06-09/10 queued save persists and a pending route save cannot replace its destination', async ({ page, browser, request }, info) => {
  test.setTimeout(120000)
  await historyJourney({ page, browser, request }, info, ['P06-09', 'P06-10'], async ({ create, receipt }) => {
    const id = await create('Route original', { slides: [slide([])] })
    const other = await create('Route destination', { slides: [slide([])] })
    await page.goto(`/editor/${id}`)
    await expect(titleInput(page)).toHaveValue('Route original')
    const held = await holdNextSave(page, id)
    await titleInput(page).fill('Route pending A')
    const body = await held.entered
    expect(body.title).toBe('Route pending A')
    await titleInput(page).fill('Route queued B')
    await expect(quick(page).getByRole('button', { name: 'Saving...', exact: true })).toBeVisible()
    held.release()
    await saved(request, id, (deck) => deck.title, 'Route queued B')
    const routeSave = await holdNextSave(page, id)
    await titleInput(page).fill('Route in-flight C')
    expect((await routeSave.entered).title).toBe('Route in-flight C')
    // SPA navigation occurs while a real PUT is suspended, not after a fabricated response.
    await page.evaluate((destination) => {
      history.pushState({}, '', `/editor/${destination}`)
      window.dispatchEvent(new PopStateEvent('popstate'))
    }, other)
    await expect(titleInput(page)).toHaveValue('Route destination')
    routeSave.release()
    await saved(request, id, (deck) => deck.title, 'Route in-flight C')
    await expect(titleInput(page)).toHaveValue('Route destination')
    expect((await apiGetPresentation(request, other)).title).toBe('Route destination')
    await page.goto(`/editor/${id}`)
    await expect(titleInput(page)).toHaveValue('Route in-flight C')
    await expect(quick(page).getByRole('button', { name: 'Undo', exact: true })).toBeDisabled()
    await page.reload()
    await expect(titleInput(page)).toHaveValue('Route in-flight C')
    receipt.runs.push({ scenarioIds: ['P06-09', 'P06-10'], status: 'pending-identity', heldBody: body.title, successorPersisted: 'Route queued B', routePendingPersistedAndReloaded: 'Route in-flight C', destinationUnchanged: true })
  })
})

test('P06-11 actual connection failure retries the queued latest edit and reloads', async ({ page, browser, request }, info) => {
  test.setTimeout(120000)
  await historyJourney({ page, browser, request }, info, ['P06-11'], async ({ create, receipt }) => {
    const id = await create('Retry original', { slides: [slide([])] })
    await page.goto(`/editor/${id}`)
    await expect(titleInput(page)).toHaveValue('Retry original')
    let arrive, release
    const entered = new Promise((resolve) => { arrive = resolve })
    const released = new Promise((resolve) => { release = resolve })
    await page.route(`**/api/presentations/${id}`, async (route) => {
      if (route.request().method() !== 'PUT') return route.continue()
      await page.unroute(`**/api/presentations/${id}`)
      arrive(route.request().postDataJSON())
      await released
      await route.abort('connectionfailed')
    })
    await titleInput(page).fill('Retry A')
    expect((await entered).title).toBe('Retry A')
    await titleInput(page).fill('Retry latest B')
    release()
    await expect(page.getByRole('button', { name: 'Retry', exact: true })).toBeVisible()
    await page.getByRole('button', { name: 'Retry', exact: true }).click()
    await saved(request, id, (deck) => deck.title, 'Retry latest B')
    await page.reload()
    await expect(titleInput(page)).toHaveValue('Retry latest B')
    receipt.runs.push({ scenarioId: 'P06-11', status: 'pending-identity', transportFailure: 'connectionfailed, no invented API body', retryAndReload: 'Retry latest B' })
  })
})

test('P06-12 Use Remote discards a queued edit after a genuine generation conflict', async ({ page, browser, request }, info) => {
  test.setTimeout(120000)
  await historyJourney({ page, browser, request }, info, ['P06-12'], async ({ ids, receipt }) => {
    const { id } = await createHistoryPackage(request, ids, 'Conflict original')
    await page.goto(`/editor/${id}`)
    await expect(titleInput(page)).toHaveValue('Conflict original')
    const held = await holdNextSave(page, id)
    await titleInput(page).fill('Conflict local A')
    const pending = await held.entered
    await titleInput(page).fill('Conflict queued B')
    const remote = await apiGetPresentation(request, id)
    await apiUpdatePresentation(request, id, { ...remote, title: 'Remote authoritative', aggregateGeneration: remote.aggregateGeneration, idempotencyKey: `p06-remote-${randomUUID()}` })
    held.release()
    const dialog = page.getByRole('alertdialog', { name: 'Save conflict' })
    await expect(dialog).toBeVisible()
    await dialog.getByRole('button', { name: 'Use Remote', exact: true }).click()
    await expect(titleInput(page)).toHaveValue('Remote authoritative')
    // Advance beyond the save debounce: a discarded queued successor must never land.
    const start = Date.now()
    await expect.poll(async () => ({
      title: (await apiGetPresentation(request, id)).title,
      quiet: Date.now() - start >= 2000,
    }), { timeout: 6000, intervals: [250, 500] }).toEqual({ title: 'Remote authoritative', quiet: true })
    await page.reload()
    await expect(titleInput(page)).toHaveValue('Remote authoritative')
    receipt.runs.push({ scenarioId: 'P06-12', status: 'pending-identity', heldBody: pending.title, discardedQueued: 'Conflict queued B', remoteAndReload: 'Remote authoritative' })
  })
})
