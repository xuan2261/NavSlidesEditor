# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: editor-status-style-runtime.tmp.spec.js >> current editor typography and Settings status runtime smoke
- Location: tests\e2e\editor-status-style-runtime.tmp.spec.js:6:5

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  getByRole('status', { name: 'Settings save status' })
Expected: "Unsaved changes"
Received: "Saved submitted snapshot; unsaved changes remain."
Timeout:  5000ms

Call log:
  - Expect "toHaveText" getByRole('status', { name: 'Settings save status' }) with timeout 5000ms
  - waiting for getByRole('status', { name: 'Settings save status' })
    14 × locator resolved to <span role="status" aria-live="polite" class="text-[13px] text-success" aria-label="Settings save status">Saved submitted snapshot; unsaved changes remain.</span>
       - unexpected value "Saved submitted snapshot; unsaved changes remain."

```

```yaml
- status "Settings save status": Saved submitted snapshot; unsaved changes remain.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | import { writeFile } from 'node:fs/promises'
  3  | import { EditorPage } from './pages/editor-page.js'
  4  | import { apiCreatePresentation, apiUpdatePresentation, apiDeletePresentation, apiGetPresentation } from './fixtures/test-fixtures.js'
  5  | 
  6  | test('current editor typography and Settings status runtime smoke', async ({ page, request }, info) => {
  7  |   const owned = []
  8  |   const receipt = { status: 'running', observations: [], browserErrors: [], limitations: ['Working-tree production Chromium surface; not hardware IME, physical Office or release qualification'] }
  9  |   page.on('pageerror', (error) => receipt.browserErrors.push(error.message))
  10 |   try {
  11 |     for (const styled of [false, true]) {
  12 |       const created = await apiCreatePresentation(request, 'Owned history smoke')
  13 |       owned.push(created.id)
  14 |       const content = styled ? '<h1 style="font-size:120px;color:#c73639">Alpha</h1>' : '<p>Alpha</p>'
  15 |       const deck = { ...created, slides: [{ id: 'owned-slide', elements: [{ id: 'owned-text', type: 'text', x: 80, y: 90, width: 650, height: 220, content }] }] }
  16 |       await apiUpdatePresentation(request, created.id, deck)
  17 |       const editor = new EditorPage(page)
  18 |       await editor.gotoPresentation(created.id)
  19 |       await editor.startEditingTextElement(0)
  20 |       const text = page.locator('.ProseMirror')
  21 |       await text.locator(styled ? 'h1' : 'p').first().click(); await page.keyboard.press('End'); await page.keyboard.type('!')
  22 |       await expect(text).toHaveText('Alpha!')
  23 |       const quick = page.getByRole('toolbar', { name: 'Quick actions' })
  24 |       await quick.getByRole('button', { name: 'Undo', exact: true }).click()
  25 |       await expect(text).toHaveText('Alpha')
  26 |       await text.locator(styled ? 'h1' : 'p').first().click(); await page.keyboard.press('End'); await page.keyboard.type('?')
  27 |       await expect(text).toHaveText('Alpha?')
  28 |       await quick.getByRole('button').first().click()
  29 |       await expect.poll(async () => (await apiGetPresentation(request, created.id)).slides[0].elements[0].content).toContain('Alpha?')
  30 |       const persisted = await apiGetPresentation(request, created.id)
  31 |       const persistedContent = persisted.slides[0].elements[0].content
  32 |       expect(persistedContent).not.toContain('!')
  33 |       if (styled) {
  34 |         expect(persistedContent).toContain('120px')
  35 |         await expect(text.locator('[style*="120px"]')).toHaveCSS('font-size', '120px')
  36 |         await expect(text.locator('[style*="120px"]')).toHaveCSS('color', 'rgb(199, 54, 57)')
  37 |       }
  38 |       await page.screenshot({ path: info.outputPath(`history-${styled ? 'styled' : 'plain'}.png`), fullPage: true })
  39 |       await page.reload(); await editor.waitForReady()
  40 |       await expect(page.getByTestId('canvas-area')).toContainText('Alpha?')
  41 |       receipt.observations.push({ kind: styled ? 'styled' : 'plain', restoredNextInputSavedAndReloaded: persistedContent })
  42 |     }
  43 |     await page.goto('/settings')
  44 |     await expect(page.getByRole('heading', { name: 'Settings', exact: true })).toBeVisible()
  45 |     const theme = page.locator('section').filter({ has: page.getByRole('heading', { name: 'Default Preferences' }) }).locator('select').first()
  46 |     await page.getByRole('button', { name: 'Save', exact: true }).click()
  47 |     const status = page.getByRole('status', { name: 'Settings save status' })
  48 |     await expect(status).toHaveText('Settings saved!')
  49 |     const accepted = await theme.inputValue()
  50 |     await theme.selectOption(accepted === 'dracula' ? 'black' : 'dracula')
> 51 |     await expect(status).toHaveText('Unsaved changes')
     |                          ^ Error: expect(locator).toHaveText(expected) failed
  52 |     await theme.selectOption(accepted)
  53 |     await expect(status).toHaveText('Settings saved!')
  54 |     await page.screenshot({ path: info.outputPath('settings-status.png'), fullPage: true })
  55 |     receipt.observations.push({ kind: 'settings', savedThenDirtyThenReverted: true })
  56 |     expect(receipt.browserErrors).toEqual([])
  57 |     receipt.status = 'passed'
  58 |   } catch (error) { receipt.status = 'failed'; receipt.error = error.stack; throw error }
  59 |   finally {
  60 |     await writeFile('plans/261009-0901-navslides-full-reliability-deep-tdd/reports/editor-status-style-runtime-current02.json', JSON.stringify(receipt, null, 2))
  61 |     for (const id of owned) await apiDeletePresentation(request, id)
  62 |   }
  63 | })
  64 | 
```