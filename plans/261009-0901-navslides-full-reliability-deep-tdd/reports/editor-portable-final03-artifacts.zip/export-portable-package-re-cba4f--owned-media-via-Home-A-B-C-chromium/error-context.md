# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: export\portable-package-real-browser.spec.js >> P10-01/12/13/14 owned media via Home A-B-C
- Location: tests\e2e\export\portable-package-real-browser.spec.js:86:7

# Error details

```
Test timeout of 180000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - application [ref=e2]:
    - generic [ref=e3]:
      - paragraph [ref=e5]: Portable browser before saveSaved before export fb8aa8f0-3db2-4a60-a281-7c8743a1b897
      - img "Owned generated image" [ref=e7]
    - complementary
    - text: Speaker notes
    - generic [ref=e14]: Portable browser before saveSaved before export fb8aa8f0-3db2-4a60-a281-7c8743a1b897. Owned generated image.
  - generic [ref=e15]:
    - button "🌓" [ref=e16] [cursor=pointer]
    - button "A+" [ref=e17] [cursor=pointer]
    - button "A−" [ref=e18] [cursor=pointer]
    - button "⛶" [ref=e19] [cursor=pointer]
```